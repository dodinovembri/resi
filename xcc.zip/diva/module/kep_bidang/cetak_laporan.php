<?php include '../koneksi.php';  ?>
<script>
function myFunction() {
  window.print();
}
</script>
<style type="text/css">
	#bd{
		padding: 20px;
	}
	#tb{
		width: 100%;
		border: 2;
	}
	#hd{
		background-color: #2e4847;
		color: #fff;
		height: 30px;
	}
	#hrk{
		height: 2px;
		background-color: #000;
	}
	#hrh{
		height: 5px;
		background-color: #2e4847;
	}
	#im{
		height: 50px;
		width: 50px;
	}
	#fnt{
		font-size: 20pt;
	}
</style>
<body id="bd" onload="myFunction()">
	<?php 		
		$q = mysqli_query($koneksi, "SELECT * FROM alternatif WHERE status='B'");
	?>
	<table>
		<tr>
			<td>
				<img src="../../img/logologo.png" id="im">
			</td>
			<td id="fnt">
				Laporan Perbaikan Jalan <br>PU. Bina Marga OI
			</td>
		</tr>
	</table>
	<hr id="hrh">
	

	<table id="tb">
		<tr id="hd">
			<td>No</td>
			<td>Nama Jalan</td>
			<td>Status</td>
		</tr>
		<?php 
			$no = 0;
			while ($r = mysqli_fetch_array($q)) { 
			$no++; ?>
			<tr>
				<td><?php echo $no; ?></td>
				<td><?php echo $r['nama_alternatif']; ?></td>
				<td><?php echo $r['status']; ?></td>
			</tr>
		<?php } ?>
	</table>
	<hr id="hrk">
	<?php 		
		$q2 = mysqli_query($koneksi, "SELECT * FROM alternatif WHERE status='P'");
	?>

	<table id="tb">
		<tr id="hd">
			<td>No</td>
			<td>Nama Jalan</td>
			<td>Status</td>
		</tr>
		<?php 
			$no = 0;
			while ($r2 = mysqli_fetch_array($q2)) { 
			$no++;	?>
			<tr>
				<td><?php echo $no; ?></td>
				<td><?php echo $r2['nama_alternatif']; ?></td>
				<td><?php echo $r2['status']; ?></td>
			</tr>
		<?php } ?>
	</table>
	<hr id="hrk">
	<?php 		
		$q3 = mysqli_query($koneksi, "SELECT * FROM alternatif WHERE status='S'");
	?>

	<table id="tb">
		<tr id="hd">
			<td>No</td>
			<td>Nama Jalan</td>
			<td>Status</td>
		</tr>
		<?php 
			$no = 0;
			while ($r3 = mysqli_fetch_array($q3)) { 
			$no++; ?>
			<tr>
				<td><?php echo $no; ?></td>
				<td><?php echo $r3['nama_alternatif']; ?></td>
				<td><?php echo $r3['status']; ?></td>
			</tr>
		<?php } ?>
	</table>
	<hr id="hrk">
</body>
