<?php
?>
<style type="text/css">
#ft{
	background-color: #000000;
	position: fixed;
	bottom: 0px;
	width: 100%;
	z-index: 100;
}
</style>
			<div id="ft">
				<div class="copyright">
					<p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
						&copy; Sistem Pendukung Keputusan Perbaikan Jalan PU. Bina Marga Kab. Ogan Ilir</p>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer section end -->


	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/circle-progress.min.js"></script>
	<script src="js/main.js"></script>

    </body>
</html>