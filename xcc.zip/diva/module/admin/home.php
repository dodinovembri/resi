<?php
?>
                                                
	<!-- Hero section -->
	<section class="hero-section set-bg">
		<div class="container" id="rumah">
			<div class="hero-slider owl-carousel">
				<!-- slider item -->
				<div class="hs-item">
					<div class="hs-content text-white">
						<h3>Sistem Pendukung Keputusan<br>Perbaikan Jalan.</h3>
						<p>Dinas Pekerjaan Umum Bina Magra Kabupaten Ogan Ilir Sumatera Selatan</p>
					</div>
					<div class="hs-preview set-bg" data-setbg="img/jalan4.jpg"></div>
				</div>
			</div>
		</div>
	</section>
	<!-- Hero section end -->
